
% results

% diary('devsim3d.txt');
% diary on;

%% with fixed cell size (one unit)

% small network, static, all free
f1=figure(1);tic,
[matrix3d400_1_0_0,positions3d400_1_0_0,w3d400_1_0_0,fc3d400_1_0_0]=devolution3d(400,1,0,0);toc
save dev3d

% small network, static, neuron can be blocked
tic,
[matrix3d400_1_1_0,positions3d400_1_1_0,w3d400_1_1_0,fc3d400_1_1_0]=devolution3d(400,1,1,0);toc
save dev3d
hgsave(f1,'small-static-fixsize');

% large network, static, all free
f2=figure(2);tic,
[matrix3d1000_1_0_0,positions3d1000_1_0_0,w3d1000_1_0_0,fc3d1000_1_0_0]=devolution3d(1000,1,0,0);toc
save dev3d

% large network, static, neuron can be blocked
tic,
[matrix3d1000_1_1_0,positions3d1000_1_1_0,w3d1000_1_1_0,fc3d1000_1_1_0]=devolution3d(1000,1,1,0);toc
save dev3d
hgsave(f2,'large-static-fixsize');

% large network, evolution, all free
f3=figure(3);tic,
[matrix3d1000_0_0_0,positions3d1000_0_0_0,w3d1000_0_0_0,fc3d1000_0_0_0]=devolution3d(1000,0,0,0);toc
save dev3d

% large network, evolution, neuron can be blocked
tic,
[matrix3d1000_0_1_0,positions3d1000_0_1_0,w3d1000_0_1_0,fc3d1000_0_1_0]=devolution3d(1000,0,1,0);toc
save dev3d
hgsave(f3,'large-evol-fixsize');






%% with fixed cell size (one unit)

% small network, static, all free
f4=figure(4);tic,
[matrix3d400_1_0_1,positions3d400_1_0_1,w3d400_1_0_1,fc3d400_1_0_1]=devolution3d(400,1,0,1);toc
save dev3d

% small network, static, neuron can be blocked
tic,
[matrix3d400_1_1_1,positions3d400_1_1_1,w3d400_1_1_1,fc3d400_1_1_1]=devolution3d(400,1,1,1);toc
save dev3d
hgsave(f4,'small-static-rndsize');

% large network, static, all free
f5=figure(5);tic,
[matrix3d1000_1_0_1,positions3d1000_1_0_1,w3d1000_1_0_1,fc3d1000_1_0_1]=devolution3d(1000,1,0,1);toc
save dev3d

% large network, static, neuron can be blocked
tic,
[matrix3d1000_1_1_1,positions3d1000_1_1_1,w3d1000_1_1_1,fc3d1000_1_1_1]=devolution3d(1000,1,1,1);toc
save dev3d
hgsave(f5,'large-static-rndsize');

% large network, evolution, all free
f6=figure(6);tic,
[matrix3d1000_0_0_1,positions3d1000_0_0_1,w3d1000_0_0_1,fc3d1000_0_0_1]=devolution3d(1000,0,0,1);toc
save dev3d

% large network, evolution, neuron can be blocked
tic,
[matrix3d1000_0_1_1,positions3d1000_0_1_1,w3d1000_0_1_1,fc3d1000_0_1_1]=devolution3d(1000,0,1,1);toc
save dev3d
hgsave(f6,'large-evol-rndsize');




w=w3d400_1_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d400_1_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w3d400_1_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d400_1_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 



w=w3d1000_1_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d1000_1_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w3d1000_1_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d1000_1_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 



w=w3d1000_0_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d1000_0_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w3d1000_0_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c3d1000_0_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 

