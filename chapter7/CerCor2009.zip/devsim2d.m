
% results

% diary('devsim3d.txt');
% diary on;

%% with fixed cell size (one unit)

% small network, static, all free
f1=figure(1);tic,
[matrix2d400_1_0_0,positions2d400_1_0_0,w2d400_1_0_0,fc2d400_1_0_0]=devolution2d(400,1,0,0);toc
save dev2d

% small network, static, neuron can be blocked
tic,
[matrix2d400_1_1_0,positions2d400_1_1_0,w2d400_1_1_0,fc2d400_1_1_0]=devolution2d(400,1,1,0);toc
save dev2d
hgsave(f1,'2dsmall-static-fixsize');

% large network, static, all free
f2=figure(2);tic,
[matrix2d1000_1_0_0,positions2d1000_1_0_0,w2d1000_1_0_0,fc2d1000_1_0_0]=devolution2d(1000,1,0,0);toc
save dev2d

% large network, static, neuron can be blocked
tic,
[matrix2d1000_1_1_0,positions2d1000_1_1_0,w2d1000_1_1_0,fc2d1000_1_1_0]=devolution2d(1000,1,1,0);toc
save dev2d
hgsave(f2,'2dlarge-static-fixsize');

% large network, evolution, all free
f3=figure(3);tic,
[matrix2d1000_0_0_0,positions2d1000_0_0_0,w2d1000_0_0_0,fc2d1000_0_0_0]=devolution2d(1000,0,0,0);toc
save dev2d

% large network, evolution, neuron can be blocked
tic,
[matrix2d1000_0_1_0,positions2d1000_0_1_0,w2d1000_0_1_0,fc2d1000_0_1_0]=devolution2d(1000,0,1,0);toc
save dev2d
hgsave(f3,'2dlarge-evol-fixsize');






%% with fixed cell size (one unit)

% small network, static, all free
f4=figure(4);tic,
[matrix2d400_1_0_1,positions2d400_1_0_1,w2d400_1_0_1,fc2d400_1_0_1]=devolution2d(400,1,0,1);toc
save dev2d

% small network, static, neuron can be blocked
tic,
[matrix2d400_1_1_1,positions2d400_1_1_1,w2d400_1_1_1,fc2d400_1_1_1]=devolution2d(400,1,1,1);toc
save dev2d
hgsave(f4,'2dsmall-static-rndsize');

% large network, static, all free
f5=figure(5);tic,
[matrix2d1000_1_0_1,positions2d1000_1_0_1,w2d1000_1_0_1,fc2d1000_1_0_1]=devolution2d(1000,1,0,1);toc
save dev2d

% large network, static, neuron can be blocked
tic,
[matrix2d1000_1_1_1,positions2d1000_1_1_1,w2d1000_1_1_1,fc2d1000_1_1_1]=devolution2d(1000,1,1,1);toc
save dev2d
hgsave(f5,'2dlarge-static-rndsize');

% large network, evolution, all free
f6=figure(6);tic,
[matrix2d1000_0_0_1,positions2d1000_0_0_1,w2d1000_0_0_1,fc2d1000_0_0_1]=devolution2d(1000,0,0,1);toc
save dev2d

% large network, evolution, neuron can be blocked
tic,
[matrix2d1000_0_1_1,positions2d1000_0_1_1,w2d1000_0_1_1,fc2d1000_0_1_1]=devolution2d(1000,0,1,1);toc
save dev2d
hgsave(f6,'2dlarge-evol-rndsize');




w=w2d400_1_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d400_1_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w2d400_1_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d400_1_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 



w=w2d1000_1_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d1000_1_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w2d1000_1_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d1000_1_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 



w=w2d1000_0_0_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d1000_0_0_1=[c(1) c(2) c(3) gof1.adjrsquare] 

w=w2d1000_0_1_1;[y,x]=hist(w); y = y / length(w);
x = [0 x]; y = [0 y]; [fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1); c2d1000_0_1_1=[c(1) c(2) c(3) gof1.adjrsquare] 

