function [matrix,positions,w,fc]=devolution3d(n,flagstatic,flagtaken,flagsize);
% function [matrix,positions,w,fc]=devolution3d(n,flagstatic,flagtaken,flagsize);
% wire n nodes by establishing a connection
% nodes of size 1 are randomly positioned on a
% 34x34x34 grid
% if flag is set, the development is static,
% that means that all nodes are positioned before
% connections are established
% output: matrix: n x n
%         positions: 3D coordinates (range 0..limit)
%         w: metric lengths of all connections
%         fc: filling fraction (see Stepanyants2002)
% Author: Marcus Kaiser  Date: 12 Dec 2006



% initialisation of node positions
LIMIT=34; % 39304 positions, about 4 times as many as for 2D 
          % in order have a comparable chance for establishing 
          % a cell position without cell overlap
MINSIZE=0; % was 2
fc=0;

if flagsize == 0
  cellsize = ones(n,1); % unit cell size
else
  cellsize = 2*rand(n,1); % random cell size in[0,2], average 1
end

positions = zeros(n,3);
positions(1,:) = [LIMIT/2, LIMIT/2, LIMIT/2];
for i=2:n
    positions(i,:) = LIMIT*rand(1,3);
    d=dist(positions(1:i,:)');
    d2=d(i,1:i-1);
    [d3,j] = min(d2); 
    while (d3(1)-cellsize(i)-cellsize(j(1))) < MINSIZE
        positions(i,:) = LIMIT*rand(1,3);
        d=dist(positions(1:i,:)');
        d2=d(i,1:i-1);
        [d3,j] = min(d2); 
    end;
end;
 
% min(nonzeros(dist(positions')))

matrix = zeros(n);
finished = zeros(n,1); % neuron already has an incoming connection
                       % and can not establish another one

for i=1:n
    phi = 2*pi*rand(1); % growth direction
    theta  = 2*pi*rand(1);
    pos = positions(i,:);
    while withingrid(pos,LIMIT)
        pos = pos + [sin(theta)*cos(phi), sin(theta)*sin(phi), cos(theta)];
        if flag==1
           nn = nearestnode(positions,multipos(pos,n),i);
        else
           nn = nearestnode(positions(1:i,:),multipos(pos,i),i);
        end;
        if (nn ~= i) & (nn ~= 0)
           fc = fc + 1;
           if (flagtaken == 0) | (finished(nn) == 0) 
              matrix(i,nn) = 1;
              %matrix(nn,i) = 1;
              finished(nn) = 1;
              break;
           end;
        end; % if
    end; % while
end; % for i



% draw results
if flagtaken == 0
    subplot(2,2,1);
    gplot(matrix,positions(:,1:2),'o-');
    text(-LIMIT/5,LIMIT * 1.0,'A');
    axis tight;
else
    subplot(2,2,3);
    gplot(matrix,positions(:,1:2),'o-');
    text(-LIMIT/5,LIMIT * 1.0,'C');
    axis tight;
end;

if flagtaken == 0
    subplot(2,2,2);
else
    subplot(2,2,4);
end;

w = nonzeros(matrix.*dist(positions'));
fc = length(w) / fc;
[y,x]=hist(w);
y = y / length(w);
x = [0 x];
y = [0 y];
plot(x,y,'kx');
hold on;
%[fit1,gof1,out1] = fit(x',y','exp1')
[fit1,gof1,out1] = fit(x',y','gauss1')
c=coeffvalues(fit1);
xs=0:max(x)/20:max(x);
ys=zeros(length(xs),1);
for i=1:length(xs)
    ys(i)= c(1)*exp(-((xs(i)-c(2))/c(3))^2);
end;
plot(xs,ys,'k-');
xlabel('Connection length');
ylabel('Frequency');
axis tight;
b=axis; 
if flagtaken == 0
    text(-max(x)/5, b(4) *1.0,'B');
else
    text(-max(x)/5, b(4) *1.0,'D');
end;


fprintf('Number of edges: %d\n', length(w));
fprintf('Edge density: %f\n', length(w)/(n*(n-1)));
fprintf('Percentage of filled slots: %f\n', n/(LIMIT*LIMIT*LIMIT));
%fprintf('Exponential parameter mu: %f\n', expfit(w));

%l=wirelengths2(celegans131matrix,celegans131positions);[y,x]=hist(l);figure(1);plot(x,y);figure(2);plot(x,length(l)*exppdf(x,expfit(l)));expfit(l)
% l=[];for i=1:20;[matrix,positions,w]=devolution(400,1);l=[l w];end;[y,x]=hist(nonzeros(l));cftool(x,y)
return




function nn=withingrid(pos,limit);
nn = 0;
if (pos(1)>0) & (pos(2)>0) & (pos(3)>0) & (pos(1)<limit) & (pos(2)<limit) & (pos(3)<limit)
   nn = 1;
end;
return;

function nn = nearestnode(positions,pos, i);
p2 = abs(positions-pos);
a = max(p2');
[val,loc] = min(a);
if (loc ~= i) & (val<=1)
    nn = loc;
else
    nn = 0;
end;
return;

function mpos = multipos(pos,n);
mpos=[];
for i=1:n
    mpos = [mpos; pos];
end;