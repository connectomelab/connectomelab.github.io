function plot_results(WINDOWLIST,NODESLIST,INTLIST,A,tit)
% function plot_results(WINDOWLIST,NODESLIST,INTLIST,A,tit)
% plot results for stat_script and degree_script
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-14


pos=[360 216 418 706];
rot=[0.3987 -0.9171 -0.0000 0.2592;
    0.0799 0.0348 0.9962 -0.5554;...
    0.9136 0.3972 -0.0872 8.0484;...
    0 0 0 1.0000];
pic = slice(WINDOWLIST,NODESLIST,INTLIST,A,[],[],[0.1:0.05:0.6]);
set(pic,'YData',(3:10));
set(pic,'XData',(50:50:400));
title(tit);
colorbar;
xlabel('Number of nodes');
ylabel('Time windows');
zlabel('Integral');
xlim([50,400]);
ylim([3,10]);
set(gcf,'Position',pos);
view(rot);
end