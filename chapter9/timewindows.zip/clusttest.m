% clusttest


tic,
mc1 = clustering(matrix);
toc

tic,
[mc2,order,values] = clustering_by_matching(matrix);
toc


%figure(1);
subplot(2,2,1);
spy(matrix);
title('Original network (ordered by NMDS)');

subplot(2,2,2);
spy(mc1);
title('ordered by median matching area');

subplot(2,2,3);
spy(mc2);
title('ordered by next best matching area');

subplot(2,2,4);
plot(values);
title('matching index of next best area');