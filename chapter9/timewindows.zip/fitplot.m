function fitplot(A_Data, axis, tw_type, model)
% function fitplot(A_Data, axis, tw_type, model)
% plots a fitted function through collapsed A_Data (see corrtest)
% axis is one of 'nodes', 'windows', 'integral'
% tw_type is one of 'all', 'theeonly', 'nothree'
% model is fit model, see cflibhelp for help
% Author:           Florian Nisbach
% Date of creation: 2006-09-13
% Last change:      2006-09-13

INTLIST=(0.1:0.05:0.6);
NODESLIST=(50:50:400);
WINDOWLIST=(3:10);

switch axis
    case 'nodes'
        XData=NODESLIST;
        switch tw_type
            case 'all'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(:,i,:)));
                end
            case 'threeonly'
                for i=1:length(XData)
                    YData(i)=mean(A_Data(1,i,:));
                end
            case 'nothree'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(2:8,i,:)));
                end

            otherwise
                error('Unknown tw_type!');
        end
    case 'windows'
        switch tw_type
            case 'all'
                XData=WINDOWLIST;
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(i,:,:)));
                end
            case 'threeonly'
                error('Silly parameter combination!')
            case 'nothree'
                XData=WINDOWLIST(2:8);
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(i,:,:)));
                end
            otherwise
                error('Unknown tw_type!');
        end
    case 'integral'
        XData=INTLIST;
        switch tw_type
            case 'all'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(:,:,i)));
                end
            case 'threeonly'
                for i=1:length(XData)
                    YData(i)=mean(A_Data(1,:,i));
                end
            case 'nothree'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(2:8,:,i)));
                end
            otherwise
                error('Unknown tw_type!');
        end
    otherwise
        error('Unknown axis!');
end
hold off;
plot(XData,YData,'Linestyle','none','Marker','+');
hold;
fresult=fit(XData',YData',model)
XFine=(min(XData):(max(XData)-min(XData))/100:max(XData));
plot(XFine,fresult(XFine));