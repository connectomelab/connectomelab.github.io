function  [r,lambda] = cumprobdist_ng(dl);
% [r,lambda] = cumprobdist(dl)
% same as cumprobdist, only without graphical output
% given the degree list, calculates the
% cumulative distribution
% and yields linear fit correlation 
% coeffcient r and (negative) steepness
% lambda of linear fit.
% Reference: Yook2002 for cumulative distribution
%            Newman2001 for uniform width binning
% Author: Marcus Kaiser   Date: 8.12.2002
% changed by:       Florian Nisbach
% Last change:      2006-08-15
NODES = length(dl);
%distinctdegrees = length( union(dl,dl) );
distinctdegrees = length( unique(dl) );
BINS = min(round( distinctdegrees / 2 ), round(sqrt(NODES)) );

maxdeg = max(dl);
degstep = maxdeg/BINS;
binedges = 1:degstep:maxdeg+1;

[y,x] = hist(dl,binedges);
for i=1:length(x)
    y(i)=length( find( dl >= x(i) ) );
end;
%loglog(x,y ./ NODES,'bd');
%xlabel('k','FontName','Arial','FontSize',10,'FontAngle','Italic');
%ylabel('Cumulative P(k)','FontName','Arial','FontSize',10,'FontAngle','Italic');


index = find(y);
[p,S] = polyfit(log(x(index)),log(y(index)),1);
lambda = -p(1);
logfit = polyval(p,log(x(index)));
rm = corrcoef(log(y(index)),logfit);
r = rm(2,1);


return