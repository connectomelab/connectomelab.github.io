function [matrix,position,matrixc,d,cl,shp] = timewin3d(nodes,windows, integral, random);
% function [matrix,position,matrixc,d,cl,shp] = timewin3d(nodes,windows);
% Program:     timewinspatialgrowth(param) - spatial network growth
%              using time windows and different node classes 
%              (graph coloring)
% Author:      Marcus Kaiser
%              International University Bremen, Germany
% Changed by:  Florian Nisbach
% Date:        31 Jan 2006 (14 Jun 2003)
% Last change: 2006-08-17

% constants
NODES = nodes;
CLASSES = windows;
INTEGRAL = integral;
BINS = 10;
TRIALS = 1;
PREVIOUSTRIALS = 0;

% parameters

% alpha
alpha = 6;   % 20 for n=1000; 40 for n=500; 150 for n=100;
              % 5 cat (border); 100 cat (unlimited)
              % 8 macaque (border)
astep = 0;%.25;

% beta
beta = 6;    % was 2.5; probability threshold to get right density
            % 0.001 for sparse networks
radius = 0.3;
            

% variables
matrix = zeros(NODES,NODES);        % connectivity matrix (no distances!)
position = zeros(NODES,3);          % (x,y) positions of the nodes
distance = zeros(NODES,1);          % distances of new node to existing nodes
timewindow = zeros(CLASSES,2);      % mu and sigma
nodeclass = zeros(NODES,1);         % class of each node
interclassedges = 0;                % number of classes between edges
edgeshistogram = zeros(CLASSES,1);% histogram of edges, sorted by disstance of the time windows

switch CLASSES
    case {2,3}
        for i=1:CLASSES
            position(i,:) = [radius*cos(i*2*pi/CLASSES) radius*sin(i*2*pi/CLASSES) 0];
            timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
    case 4         % tetrahedron
        for i=1:CLASSES
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            %timewindow(i,:) = [0.5, 0.3];
            nodeclass(i) = i;
        end;
        radius = radius * sqrt(3)/2;
        position(1,:) = [ 0, radius*(sqrt(3) - 1/sqrt(3)),             0];
        position(2,:) = [-radius,         - radius/sqrt(3),             0];
        position(3,:) = [ radius,         - radius/sqrt(3),             0];
        position(4,:) = [ 0,                   0, radius*  2/ sqrt(3)];
%        position(4,:) = [ 0,                   0, 2 *  radius * sqrt(2/3) ];        
%         for i=1:CLASSES
%           sqrt( position(i,1)^2 + position(i,2)^2 + position(i,3)^2 )
%         end;  
        
    case 6        % octahedron
        for i=1:6
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
        position(1,:) = [ radius,  0,  0];
        position(2,:) = [ 0,  radius,  0];
        position(3,:) = [ 0,  0,  radius];
        position(4,:) = [-radius,  0,  0];
        position(5,:) = [ 0, -radius,  0];
        position(6,:) = [ 0,  0, -radius];        
    case 8        % cube
        for i=1:CLASSES       
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
        radius = radius/sqrt(2);
        position(1,:) = [-radius, -radius, -radius];
        position(2,:) = [-radius,  radius, -radius];
        position(3,:) = [ radius, -radius, -radius];
        position(4,:) = [ radius,  radius, -radius];
        position(5,:) = [-radius, -radius,  radius];
        position(6,:) = [-radius,  radius,  radius];
        position(7,:) = [ radius, -radius,  radius];
        position(8,:) = [ radius,  radius,  radius];
    otherwise 
        disp('Warning: Nodes could not be arranged equidistant on a sphere!');
        disp('         Instead they are arranged equidistant on a circle...');        
        for i=1:CLASSES
            position(i,:) = [radius*cos(i*2*pi/CLASSES) radius*sin(i*2*pi/CLASSES) 0];
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
end;
% overwrite the pioneer node position with random values, following the
% distribution of the other nodes:
if random == 1
    for i = 1:CLASSES
        dummy = 2*rand(1,3);
        % dummy(1): phi, dummy(2): theta, dummy(3): r  
        position(i,:) = [ dummy(3) * cos(dummy(1)*2*pi) * cos(dummy(2)*2*pi), ...
                        dummy(3) * cos(dummy(1)*2*pi) * sin(dummy(2)*2*pi), ...
                        dummy(3) * sin(dummy(1)*2*pi) ];
    end
end

    % and once again... :)        
%for i=1:CLASSES
%            
%            %timewindow(i,:) = [i/(CLASSES+1), 0.8/CLASSES];
%            timewindow(i,:) = [i/(CLASSES+1), sigma(i/(CLASSES+1),integral)];
%            nodeclass(i) = i;
%        end;

%this is now done by prepareParmVector:
timewindow = prepareParmVector(CLASSES, integral);
disp('sigma calculations done!');
n = CLASSES + 1;

tic;
while n <= NODES
  t = n/NODES; % relative time (t=1 at the end of development)
  dummy = 2*rand(1,3);
  % dummy(1): phi, dummy(2): theta, dummy(3): r  
  position(n,:) = [ dummy(3) * cos(dummy(1)*2*pi) * cos(dummy(2)*2*pi), ...
                    dummy(3) * cos(dummy(1)*2*pi) * sin(dummy(2)*2*pi), ...
                    dummy(3) * sin(dummy(1)*2*pi) ];
  %position(n,:) = rand(1,3);    % random position for candidate node
  for k=1:CLASSES
     classdistance(k) = sqrt( (position(n,1)-position(k,1))^2 + (position(n,2)-position(k,2))^2 + (position(n,3)-position(k,3))^2 );
  end;
  [dummy, nclass] = min(classdistance);
  nodeclass(n) = nclass;
  %normn = normdist(t,timewindow(nodeclass(n),1),timewindow(nodeclass(n),2));
  normn = ptimepoly(t,timewindow(nodeclass(n),1),timewindow(nodeclass(n),2));
%      normn = 1;
  
  for i=1:n-1                   % distances to node n
      distance(i) = sqrt( (position(n,1)-position(i,1))^2 + (position(n,2)-position(i,2))^2 + (position(n,3)-position(i,3))^2 );        
      probspatial = beta * exp( -alpha * distance(i) );   % spatial contraint
      %probtime = normn * normdist(t,timewindow(nodeclass(i),1),timewindow(nodeclass(i),2));% time window constraint
      probtime = normn * ptimepoly(t,timewindow(nodeclass(i),1),timewindow(nodeclass(i),2));% time window constraint
%          probtime = exp( -alpha * distance(nclass)) * normdist(n-i,0,5) * normdist(t,timewindow(nclass,1),3*timewindow(nclass,2));
      if rand(1) <= probspatial * probtime
          matrix(i,n) = nodeclass(n);
          matrix(n,i) = nodeclass(n);
          if nodeclass(i) ~= nodeclass(n)
              interclassedges = interclassedges + 1;
          end;
          edgeshistogram(abs(nodeclass(n)-nodeclass(i))+1) = edgeshistogram(abs(nodeclass(n)-nodeclass(i))+1) + 1;
      end; % if
  end; % for
  if deg(matrix,n) > 0 
      n = n + 1;
      alpha = alpha + astep;
  end; % if
end; % while n
t=toc;
matrixc = clustering(matrix);

% degree distribution
dl = degrees(matrix) / 2;  % assume undirected graph
maxdeg = max(dl);

% color map
cmap = zeros(CLASSES+1,3);
cmap(1,:) = [1 1 1];
for c=1:CLASSES
  cmap(c+1,:) = [c/CLASSES 1-(c/CLASSES) 1/c^2];
end;

% probability densities for synaptogenesis  
probdensity = zeros(CLASSES,81);
for c=1:CLASSES
  for t=1:81
      %probdensity(c,t)=ptimecos((t-1)/80,normdist(c,1),timewindow(c,2))/80;
      probdensity(c,t)=ptimepoly((t-1)/80,timewindow(c,1),timewindow(c,2));
  end;
  sum(probdensity(c,:));
end;



% network visualization
%snggraph3d
clf;
figure(1); 
cl = clustercoeff(matrix);
title('test');
subplot(3,4,1);
title(strcat('N = ',num2str(NODES),'  E = ',num2str(nnz(matrix)/2),'  d = ',num2str(density(matrix)), '  CC = ',num2str(cl) ));
hold on;
for i=1:CLASSES
plot3(position(i,1),position(i,2),position(i,3),'+','Color',cmap(1+nodeclass(i),:));
end;
hold on;
for i=CLASSES+1:NODES
plot3(position(i,1),position(i,2),position(i,3),'o','Color',cmap(1+nodeclass(i),:));
end;
hold off;
%gplot(matrix,position,'b-');

subplot(3,4,2);
hist(dl);  
title('degree distribution');
xlabel('degree');
ylabel('occurrences');    

%axes('Position', [0.54 0.83 0.075 0.075]);

subplot(3,4,3);
[r,lambda] = cumprobdist(dl);
%fprintf('degrees: r=%f, lambda=%f',r,lambda);
%title('cumulated degree distribution');

subplot(3,4,6);
l=wirelengths(matrix,position);
hist(l);
title('wire length distribution');
ylabel('occurrences');
xlabel('distance');
axis tight;

%axes('Position', [0.54 0.83 0.075 0.075]);
subplot(3,4,7);
%loglog(hist(l));
[r,lambda] = cumprobdist(l);
%fprintf('wiring: r=%f, lambda=%f',r,lambda);
hold on;
x = max(l)/2:max(l)/20:max(l);
plot(x, beta * exp(-alpha * x),'b-');


subplot(3,4,5);
hold on;
for c=1:CLASSES
  plot(0:0.0125:1, probdensity(c,:), 'Color', cmap(c+1,:));
end;
xlabel('relative time');
ylabel('probability');
hold off;



subplot(3,4,4);
pcolor(matrix);
shading flat;
colormap(cmap);
title('timed adjacency matrix');
axis off;

subplot(3,4,8);
pcolor(matrixc);
shading flat;
colormap(cmap);
title('clustered adjacency matrix');  
axis off;
hold off;

subplot(3,4,9);
plot(edgeshistogram);
title('edges histogram');
ylabel('occurrences');
xlabel('cluster number difference + 1');
axis tight;


% network properties  
d = density(matrix);
if n < 300
  shp = asp(matrix);
else
  shp = -1;
end;  


% output network parameters and properties
fprintf('Calculation Time: %f seconds    n=%d\n',t,NODES);
fprintf('a  = %f    astep= %f\n',alpha,astep);
fprintf('c  = %f\n\n',beta);

fprintf('cl = %f\n',cl);
fprintf('d  = %f\n',d);
fprintf('asp= %f\n\n',shp);

fprintf('r  = %f\n',r);
fprintf('lambda = %f\n\n',lambda);

fprintf('total wiring length = %f\n',wiringlength(matrix,position));

fprintf('number of inter cluster edges = %f\n', interclassedges);
fprintf('fraction of inter cluster edges = %f\n', interclassedges/(nnz(matrix)/2));
fprintf('Edge histogram\n');
for i=1:CLASSES
    fprintf('number of edges of cluster difference %f:  %f\n',i-1,edgeshistogram(i));
end;
if NODES>200
    return
end;

figure(2);  
title(strcat('N = ',num2str(NODES),'  E = ',num2str(nnz(matrix)/2),'  d = ',num2str(density(matrix)), '  CC = ',num2str(clustercoeff(matrix)) ));
hold on;
for i=1:CLASSES
  plot3(position(i,1),position(i,2),position(i,3),'+','Color',cmap(1+nodeclass(i),:));
end;
hold on;
for i=CLASSES+1:NODES
  plot3(position(i,1),position(i,2),position(i,3),'o','Color',cmap(1+nodeclass(i),:));
end;
for i=1:NODES
    for j=1:NODES
        if matrix(i,j) ~= 0
            line([position(i,1) position(j,1)],[position(i,2) position(j,2)],[position(i,3) position(j,3)], 'Color',cmap(1+nodeclass(i),:));
        end;
    end;
end;
for i=1:CLASSES
    for j=i:CLASSES
%        line([position(i,1) position(j,1)],[position(i,2) position(j,2)],[position(i,3) position(j,3)]);
    end;
end;
axis equal;
rotate(gca,[pi/4 pi/4], pi/4);
hold off;


return;




function r = normdist(t,mu,sigma);
  r = (1/(sigma*sqrt(2*pi))) * exp(- (   ((t-mu)^2) / (2*(sigma^2)) ));
return

function p = ptimecos(t,mu,sigma);
    lambda=-log(2)/log(mu);
    p=(-((cos(2*pi*t^lambda)-1)/2))^(1/sigma)+0.1;
return;