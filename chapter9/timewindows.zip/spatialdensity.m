function dmatrix = spatialdensity(positions);
% dmatrix = spatialdensity(positions);
% calculates spatial density

%dummy = round( max(positions) / 0.1 );
%xm = dummy(1);
%ym = dummy(2);

xm = 10;
ym = 15;

dmatrix = zeros(xm, ym);

for x=1:xm
  for y=1:ym
    dmatrix(x, y)=length( find( ((positions(:,1)>x*0.1-0.1) ...
                               & (positions(:,1)<x*0.1) ...
                               & (positions(:,2)>y*0.1-0.1) ...
                               & (positions(:,2)<y*0.1)) ) );
  end;
end;


return;