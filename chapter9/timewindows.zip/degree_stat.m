function out = degree_stat(nodes, windows, Integral, numruns)
% function out = degree_stat(nodes, windows, Integral, numruns)
% runs degree_stw several times and to calculate mean and estimate for
% standard deviation.
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-14


runs=numruns;
%a_dd_r=zeros(runs,1);
%a_dd_lambda=zeros(runs,1);
%a_wiring_total=zeros(runs,1);
%a_CC=zeros(runs,1);
%a_ASP=zeros(runs,1);
%a_Edges=zeros(runs,1);
%a_FQuartEdges=zeros(runs,1);
a_quantiles=zeros(runs,101);
a_runtime=zeros(runs,1);
a_dd_r=zeros(runs,1);
a_dd_lambda=zeros(runs,1);

pv=prepareParmVector(windows,Integral);

for i=1:runs
    %[a_dd_r(i),a_dd_lambda(i),a_wiring_total(i),a_CC(i),a_ASP(i),a_Edges(i),a_FQuartEdges(i),a_runtime(i)]=simulateTimeWindows(nodes,windows,pv);
    [a_quantiles(i,:),a_dd_r(i),a_dd_lambda(i),a_runtime(i)] = degree_stw(nodes, windows, pv);
    fprintf('Run No. %i done!\n',i);
end
%{
dd_r(1)=mean(a_dd_r);dd_r(2)=std(a_dd_r)/sqrt(runs);
dd_lambda(1)=mean(a_dd_lambda);dd_lambda(2)=std(a_dd_lambda)/sqrt(runs);
wiring_r(1)=mean(a_wiring_r);wiring_r(2)=std(a_wiring_r)/sqrt(runs);
wiring_lambda(1)=mean(a_wiring_lambda);wiring_lambda(2)=std(a_wiring_lambda)/sqrt(runs);
wiring_total(1)=mean(a_wiring_total);wiring_total(2)=std(a_wiring_total)/sqrt(runs);
CC(1)=mean(a_CC);CC(2)=std(a_CC)/sqrt(runs);
ASP(1)=mean(a_ASP);ASP(2)=std(a_ASP)/sqrt(runs);
Edges(1)=mean(a_Edges);Edges(2)=std(a_Edges)/sqrt(runs);
%}
for j=1:101
    out.quantiles(j)=mean(a_quantiles(:,j));
    out.quantiles_std(j)=std(a_quantiles(:,j))/sqrt(runs);    
out.runtime(1)=mean(a_runtime);
out.runtime(2)=std(a_runtime)/sqrt(runs);
out.dd_r(1)=mean(a_dd_r);
out.dd_r(2)=std(a_dd_r)/sqrt(runs);
out.dd_lambda(1)=mean(a_dd_lambda);
out.dd_lambda(2)=std(a_dd_lambda)/sqrt(runs);
end