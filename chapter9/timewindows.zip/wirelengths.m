function l = wirelengths(matrix,positions)
% l = wirelengths(matrix,positions)
% wiring lengths of network with spatial node positions
% works for two- or three-dimensional positions
% an undirected network is needed!
% yields lengths of all edges
% Author: Marcus Kaiser  Date: 15 Jun 2004


n=size(positions,1);

count=1;
l=zeros(nnz(matrix)/2,1);
for i=1:n
    for j=1:i-1 % include only edges of triangular matrix
                % so that bidirectional links are not counted twice
        if matrix(i,j) ~= 0
            % add euklidian distance between i and j to wiring length
            l(count) = sum(( positions(i,:) - positions(j,:) ).^2).^0.5;
            count = count + 1;
        end;
    end;
end;


return