function s = sigma(mu, I)
% function s = sigma(mu, I)
% compute the exponent sigma for the time window function ptimepoly
% NOTE: mu (x-value of the peak) and I (desired integral) must be
% between 0 and 1!
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-14

    function pint = ptint(mu,sig,I)
        pint = quadv(@(x)ptimepoly(x,mu,sig),0,1) - I;
    end
    %warning off all;
    %warning off 'MATLAB:polyfit:PolyNotUnique';
    %s = fsolve(@(sig)ptint(mu,sig,I),1);
    % right and left end of pint (w.r.t. I) are not suitable for
    % fsolve, which uses Newton iteration. So lets do it by hand...
    if (I<0)|(I>1)|(mu<0)|(mu>1)
        error('Both parameters must be between 0 and 1!');
    else 
        upper = 1.0;
        lower = 1.0;
    
        while ptint(mu,upper,I)<0
            upper=upper*2.0;
        end
    
        while ptint (mu,lower,I)>0
            lower=lower/2.0;
        end
    
        while abs(ptint(mu,(upper+lower)/2.0,I))>10e-6
            if ptint(mu,(upper+lower)/2.0,I)>0
                upper=(upper+lower)/2.0;
            else
                lower=(upper+lower)/2.0;
            end
        end
        s = (upper+lower)/2.0;
    end
end