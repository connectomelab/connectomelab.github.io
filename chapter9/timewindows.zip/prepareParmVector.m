function musigma = prepareParmVector(windows, Integral);
% function musigma = prepareParmVector(windows, Integral);
% calculates the mu and sigma vector for the time window functions
% (TWF), taking the number of windows and the desired value of the
% integral over the TWFs over the interval [0,1].
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-14
    musigma = zeros(windows,2);
    for i=1:windows
        musigma(i,:) = [i/(windows+1), sigma(i/(windows+1),Integral)];
    end;
return
  