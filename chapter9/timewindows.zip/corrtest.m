function corrtest(A_Data, axis, tw_type)
% function corrtest(A_Data, axis, tw_type)
% tests the correlation of A_Data (A_ASP and so on, as given from stat_script)
% axis is one of 'nodes', 'windows', 'integral'
% tw_type is one of 'all', 'theeonly', 'nothree'
% Author:           Florian Nisbach
% Date of creation: 2006-09-13
% Last change:      2006-09-13

INTLIST=(0.1:0.05:0.6);
NODESLIST=(50:50:400);
WINDOWLIST=(3:10);

switch axis
    case 'nodes'
        XData=NODESLIST;
        switch tw_type
            case 'all'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(:,i,:)));
                end
            case 'threeonly'
                for i=1:length(XData)
                    YData(i)=mean(A_Data(1,i,:));
                end
            case 'nothree'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(2:8,i,:)));
                end

            otherwise
                error('Unknown tw_type!');
        end
    case 'windows'
        switch tw_type
            case 'all'
                XData=WINDOWLIST;
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(i,:,:)));
                end
            case 'threeonly'
                error('Silly parameter combination!')
            case 'nothree'
                XData=WINDOWLIST(2:8);
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(i,:,:)));
                end
            otherwise
                error('Unknown tw_type!');
        end
    case 'integral'
        XData=INTLIST;
        switch tw_type
            case 'all'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(:,:,i)));
                end
            case 'threeonly'
                for i=1:length(XData)
                    YData(i)=mean(A_Data(1,:,i));
                end
            case 'nothree'
                for i=1:length(XData)
                    YData(i)=mean(mean(A_Data(2:8,:,i)));
                end
            otherwise
                error('Unknown tw_type!');
        end
    otherwise
        error('Unknown axis!');
end
CovMatrix=cov(XData,YData);
CC=CovMatrix(1,2)/sqrt(CovMatrix(1,1)*CovMatrix(2,2));
fprintf('Correlation coefficient: %f\n',CC);
plot(XData,YData,'Linestyle','none','Marker','+');

[fresult,gof]=fit(XData',YData','poly1');
fprintf('Poly1 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','poly2');
fprintf('Poly2 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','poly3');
fprintf('Poly3 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','poly4');
fprintf('Poly4 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','exp1');
fprintf('Exp1 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','power1');
fprintf('Power1 gave r^2=%f\n',gof.rsquare);

[fresult,gof]=fit(XData',YData','power2');
fprintf('Power2 gave r^2=%f\n',gof.rsquare);

