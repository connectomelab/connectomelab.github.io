function circulargraph2(matrix,labels);
% circulargraph2(matrix,labels)
% Author: Marcus Kaiser  Date: 3 July 2006

NODES = length(matrix);
position = zeros(NODES,2);
step = 2 * pi / NODES;
for i=1:NODES
    position(i,:) = [cos(i*step) sin(i*step)];    
end;
plot(position(:,1),position(:,2),'bo');
hold on;

% draw network
for i=1:NODES
    %text(position(i,1),position(i,2),labels(i));
    for j=1:NODES
        if matrix(i,j) ~= 0
           line([position(i,1) position(j,1)],[position(i,2) position(j,2)],'Color',[0 0 0.5]);
        end
    end
end
axis off;
hold off;