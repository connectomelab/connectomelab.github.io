function [matrixc,i] = clustering(matrix)
% [matrixc,i] = clustering(matrix)
% permutates node sequence to
% generate clusters in adjacency matrix
% yields:
%    matrixc: clustered adjacency matrix
%    i: new node sequence
% Author: Marcus Kaiser  Date: 10 Oct 2003 


n = length(matrix);
center = zeros(n,1);

% get center (average) of node 
for i=1:n
    outarray = matrix(i,:).*(1:n);
    [dummy,dummy2,outindices]=find(outarray);
    outcenter = median(outindices);
    
    inarray = matrix(:,i).*(1:n)';
    [dummy,dummy2,inindices]=find(inarray);
    incenter = median(inindices);
    
    center(i) = mean([outcenter,incenter]);    
end

[dummy,i] = sort(center);

matrixc = matrix(i,i);


return;