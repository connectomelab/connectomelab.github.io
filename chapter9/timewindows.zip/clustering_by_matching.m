function [matrixc,matorder,matordervalues] = clustering_by_matching(matrix)
% [matrixc,matorder,matordervalues] = clustering_by_matching(matrix)
% deterministic algorithm
% generate clusters in adjacency matrix
% Author: Marcus Kaiser  Date: 29 Mar 2006 



n = length(matrix);
m = mi(matrix);
%m = matchingindex(matrix,1);
node = 1;
matorder(1) = 1;
matordervalues(1) = 0;
rest = 2:n;


for i=2:n-1
%    [s, k]=find(m(node,rest)>0);
%    nnznodes = rest(k);
    [s, node] = max(m(node,rest));
%    node = nnznodes(node);
    node = rest(node);
    rest = setdiff(rest, node); % remove node from the list of remaining nodes;
    matorder(i) = node;
    matordervalues(i) = s;
%    i;
end
matorder(n) = rest;


matrixc = matrix(matorder,matorder);


return;