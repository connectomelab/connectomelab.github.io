function [quantiles,dd_r,dd_lambda,runtime] = degree_stw(nodes, windows, ParmVector);
% function [quantiles,dd_r,dd_lambda,runtime] = degree_stw(nodes, windows,
% ParmVector);
% yet another version of simulateTimeWindows, which stores all percentiles
% of the degree distribution, as well as fit data for testing for power law
% distribution.
% based on timewin3d by Marcus Kaiser
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-14


tic;
QUANTARRAY=(0:0.01:1);
quantiles=zeros(length(QUANTARRAY),1);
%output variables
dd_r=0;
dd_lambda=0;
wiring_r=0;
wiring_lambda=0;
wiring_total=0;
CC=0;
ASP=0;
Edges=0;



NODES = nodes;
CLASSES = windows;
BINS = 10;
TRIALS = 1;
PREVIOUSTRIALS = 0;
% parameters

% alpha
alpha = 6;   % 20 for n=1000; 40 for n=500; 150 for n=100;
              % 5 cat (border); 100 cat (unlimited)
              % 8 macaque (border)
astep = 0;%.25;

% beta
beta = 6;    % was 2.5; probability threshold to get right density
            % 0.001 for sparse networks
radius = 0.3;
            

% variables
matrix = zeros(NODES,NODES);        % connectivity matrix (no distances!)
position = zeros(NODES,3);          % (x,y) positions of the nodes
distance = zeros(NODES,1);          % distances of new node to existing nodes
timewindow=ParmVector; %use pre-calculated ParmVector to speed up multiple runs
nodeclass = zeros(NODES,1);         % class of each node
interclassedges = 0;                % number of classes between edges
edgeshistogram = zeros(CLASSES,1);% histogram of edges, sorted by disstance of the time windows

switch CLASSES
    case {2,3}
        for i=1:CLASSES
            position(i,:) = [radius*cos(i*2*pi/CLASSES) radius*sin(i*2*pi/CLASSES) 0];
            timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
    case 4         % tetrahedron
        for i=1:CLASSES
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            %timewindow(i,:) = [0.5, 0.3];
            nodeclass(i) = i;
        end;
        radius = radius * sqrt(3)/2;
        position(1,:) = [ 0, radius*(sqrt(3) - 1/sqrt(3)),             0];
        position(2,:) = [-radius,         - radius/sqrt(3),             0];
        position(3,:) = [ radius,         - radius/sqrt(3),             0];
        position(4,:) = [ 0,                   0, radius*  2/ sqrt(3)];
%        position(4,:) = [ 0,                   0, 2 *  radius * sqrt(2/3) ];        
%         for i=1:CLASSES
%           sqrt( position(i,1)^2 + position(i,2)^2 + position(i,3)^2 )
%         end;  
        
    case 6        % octahedron
        for i=1:6
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
        position(1,:) = [ radius,  0,  0];
        position(2,:) = [ 0,  radius,  0];
        position(3,:) = [ 0,  0,  radius];
        position(4,:) = [-radius,  0,  0];
        position(5,:) = [ 0, -radius,  0];
        position(6,:) = [ 0,  0, -radius];        
    case 8        % cube
        for i=1:CLASSES       
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
        radius = radius/sqrt(2);
        position(1,:) = [-radius, -radius, -radius];
        position(2,:) = [-radius,  radius, -radius];
        position(3,:) = [ radius, -radius, -radius];
        position(4,:) = [ radius,  radius, -radius];
        position(5,:) = [-radius, -radius,  radius];
        position(6,:) = [-radius,  radius,  radius];
        position(7,:) = [ radius, -radius,  radius];
        position(8,:) = [ radius,  radius,  radius];
    otherwise 
        disp('Warning: Nodes could not be arranged equidistant on a sphere!');
        disp('         Instead they are arranged equidistant on a circle...');        
        for i=1:CLASSES
            position(i,:) = [radius*cos(i*2*pi/CLASSES) radius*sin(i*2*pi/CLASSES) 0];
            %timewindow(i,:) = [i/(CLASSES+1), 0.3/CLASSES];
            nodeclass(i) = i;
        end;
end;


n = CLASSES + 1;

tic;
while n <= NODES
  t = n/NODES; % relative time (t=1 at the end of development)
  dummy = 2*rand(1,3);
  % dummy(1): phi, dummy(2): theta, dummy(3): r  
  position(n,:) = [ dummy(3) * cos(dummy(1)*2*pi) * cos(dummy(2)*2*pi), ...
                    dummy(3) * cos(dummy(1)*2*pi) * sin(dummy(2)*2*pi), ...
                    dummy(3) * sin(dummy(1)*2*pi) ];
  %position(n,:) = rand(1,3);    % random position for candidate node
  for k=1:CLASSES
     classdistance(k) = sqrt( (position(n,1)-position(k,1))^2 + (position(n,2)-position(k,2))^2 + (position(n,3)-position(k,3))^2 );
  end;
  [dummy, nclass] = min(classdistance);
  nodeclass(n) = nclass;
  %normn = normdist(t,timewindow(nodeclass(n),1),timewindow(nodeclass(n),2));
  normn = ptimepoly(t,timewindow(nodeclass(n),1),timewindow(nodeclass(n),2));
%      normn = 1;
  
  for i=1:n-1                   % distances to node n
      distance(i) = sqrt( (position(n,1)-position(i,1))^2 + (position(n,2)-position(i,2))^2 + (position(n,3)-position(i,3))^2 );        
      probspatial = beta * exp( -alpha * distance(i) );   % spatial contraint
      %probtime = normn * normdist(t,timewindow(nodeclass(i),1),timewindow(nodeclass(i),2));% time window constraint
      probtime = normn * ptimepoly(t,timewindow(nodeclass(i),1),timewindow(nodeclass(i),2));% time window constraint
%          probtime = exp( -alpha * distance(nclass)) * normdist(n-i,0,5) * normdist(t,timewindow(nclass,1),3*timewindow(nclass,2));
      if rand(1) <= probspatial * probtime
          matrix(i,n) = nodeclass(n);
          matrix(n,i) = nodeclass(n);
          if nodeclass(i) ~= nodeclass(n)
              interclassedges = interclassedges + 1;
          end;
          edgeshistogram(abs(nodeclass(n)-nodeclass(i))+1) = edgeshistogram(abs(nodeclass(n)-nodeclass(i))+1) + 1;
      end; % if
  end; % for
  if deg(matrix,n) > 0 
      n = n + 1;
      alpha = alpha + astep;
  end; % if
end; % while n

%dd calculations
dl = degrees(matrix) / 2;
for i=1:length(QUANTARRAY)
    quantiles(i)=quantile(dl,QUANTARRAY(i));
end
[dd_r,dd_lambda] = cumprobdist_ng(dl);

%calculate the runtime
runtime=toc;
return