% this script was used to calculate the edges development over
% the time of network generation.
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-25



WINDOWARRAY=(3:10);
INTARRAY=(0.1:0.05:0.6);
RUNS=20;
NODESTEP=50;
NUMSTEPS=8;

EdgeDist=zeros(NUMSTEPS,RUNS);
InterEdgeDist=zeros(NUMSTEPS,RUNS);
E=zeros(NUMSTEPS,1);
I=zeros(NUMSTEPS,1);

for win_index=1:length(WINDOWARRAY)
    for int_index=1:length(INTARRAY)
        fprintf('Starting %i windows, Int=%f\n',WINDOWARRAY(win_index),INTARRAY(int_index));
        for runno=1:RUNS
            pv=prepareParmVector(WINDOWARRAY(win_index),INTARRAY(int_index));
            [E,I]=connectionHyp(NODESTEP,NUMSTEPS,WINDOWARRAY(win_index),pv);
            for i=1:NUMSTEPS
                EdgeDist(i,runno)=E(i);
                InterEdgeDist(i,runno)=I(i);
            end
        end
        for i=1:NUMSTEPS
        A_EdgeDist(win_index,int_index,i)=mean(EdgeDist(i,:));
        A_InterEdgeDist(win_index,int_index,i)=mean(InterEdgeDist(i,:));
        end
    end
end
