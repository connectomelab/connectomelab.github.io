function  dl = degrees(matrix);
% dl = degrees(matrix)
% list of degree for each node
% (degree distribution)
% Original version: Marcus Kaiser
% Author (rewrite): Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-14

%dl=sum(matrix + matrix');

%dl=sum(matrix) + sum(matrix');

if size(matrix,1)~=size(matrix,2)
    error('Only square matrices allowed!');
end
for i=1:length(matrix)
    dl(i)=nnz(matrix(i,:))+nnz(matrix(:,i))-(matrix(i,i)~=0);
end

return