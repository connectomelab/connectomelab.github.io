function rnd = randomgraph(n,e);
% rnd = randomgraph(n,e)
% yields matrix of a random graph
% with n nodes and e edges

rnd=zeros(n,n);
idx=randperm(n*n);

i=1;
count = 1;

while i <= e
    r = ceil( idx(count) / n );
    c = 1 + mod( idx(count), n );
    count = count + 1;
    if (r ~= c)
      rnd( r , c ) = 1;
      i = i + 1;
    end;
end;