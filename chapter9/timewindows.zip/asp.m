function [avg,mat] = asp(matrix)
% [avg,mat] = asp(matrix)
% Average shortest path using Floyds algorithm
% avg is the average shortest path length / characteristic path length 
% / diameter (as wrongly defined by Barabasi!)
% mat is the matrix for the length of each shortest path
% element is 100000 if no path between two nodes exists
% Author: Marcus Kaiser  Date: 15.08.02

n=length(matrix);



% preconditioning

for i=1:n
   for j=1:n
      if (matrix(i,j)==0) & (i~=j)
         matrix(i,j)=100000;
      elseif (i~=j) 
         matrix(i,j)=1;
      end;   
   end;
end;



% Floyd itelf O(n^3)

for k = 1:n
  for i = 1:n
    for j = 1:n
       if (matrix(i,k) + matrix(k,j)<matrix(i,j))
          matrix(i,j)=matrix(i,k) + matrix(k,j);
       end;   
    end;
  end;
end; 


% calculating average only accounting for the connected subgraph
% that means disregarding paths that are longer than 100 
% (normally such elements are assigned infinite path length)

count=0;
for i = 1:n
  for j = 1:n
     if (matrix(i,j)>10000)
        matrix(i,j)=0;
     elseif (matrix(i,j)~=0)
        count=count+1;
     end;
  end;
end;
avg=sum(sum(matrix))/count;
mat=matrix;

return
