function m = munion(m1,m2,m3,m4,m5)
% MUNION set1 set2 .. set5 
% MUNION unifies multiple sets (up to 5)

i=nargin;
s=union(m1,m2);
i=i-1;
if (i>1)
  s=union(s,m3);
  i=i-1;
  if (i>1)
    s=union(s,m4);
    i=i-1;
    if (i>1)
      s=union(s,m5);
    end;
  end;
end;

m=s;