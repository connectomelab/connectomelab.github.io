% script to run statistics using degree_stat
% the percentile data is stored in the 4D array A_quantiles
% r and lambda of degree distribution is stored, 
% as well as runtime
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-14


starttime=clock;
tic;

RUNS=40;
WINDOWLIST=[3,4,5,6,7,8,9,10];
NODESLIST=[50,100,150,200,250,300,350,400];
INTLIST=[0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6];

%RUNS=5;
%WINDOWLIST=[6,7];
%NODESLIST=[50,100];
%INTLIST=[0.5,0.55];

for w_index = 1:length(WINDOWLIST)
    for node_index = 1:length(NODESLIST)
        for Int_index = 1:length(INTLIST)
            fprintf('%i windows, %i nodes, Integral=%f\n',WINDOWLIST(w_index),NODESLIST(node_index),INTLIST(Int_index));
            out=degree_stat(NODESLIST(node_index),WINDOWLIST(w_index),INTLIST(Int_index),RUNS);
            A_quantiles(w_index,node_index,Int_index,:)=out.quantiles;
            A_quantiles_std(w_index,node_index,Int_index,:)=out.quantiles_std;
            A_dd_r(w_index,node_index,Int_index)=out.dd_r(1);
            A_dd_r_std(w_index,node_index,Int_index)=out.dd_r(2);
            A_dd_lambda(w_index,node_index,Int_index)=out.dd_lambda(1);
            A_dd_lambda_std(w_index,node_index,Int_index)=out.dd_lambda(2);
            A_runtime(w_index,node_index,Int_index)=out.runtime(1);
            A_runtime_std(w_index,node_index,Int_index)=out.runtime(2);
            
           
        end
    end
end
stoptime=clock;
duration=toc;
save('quantiles_data_2006_09_18.mat');
     
%{
out.dd_r(1)=mean(a_dd_r);
out.dd_r(2)=std(a_dd_r)/sqrt(runs);

out.dd_lambda(1)=mean(a_dd_lambda);
out.dd_lambda(2)=std(a_dd_lambda)/sqrt(runs);

out.wiring_r(1)=mean(a_wiring_r);
out.wiring_r(2)=std(a_wiring_r)/sqrt(runs);

out.wiring_lambda(1)=mean(a_wiring_lambda);
out.wiring_lambda(2)=std(a_wiring_lambda)/sqrt(runs);

out.wiring_total(1)=mean(a_wiring_total);
out.wiring_total(2)=std(a_wiring_total)/sqrt(runs);

out.CC(1)=mean(a_CC);
out.CC(2)=std(a_CC)/sqrt(runs);

out.ASP(1)=mean(a_ASP);
out.ASP(2)=std(a_ASP)/sqrt(runs);

out.Edges(1)=mean(a_Edges);
out.Edges(2)=std(a_Edges)/sqrt(runs);
%}