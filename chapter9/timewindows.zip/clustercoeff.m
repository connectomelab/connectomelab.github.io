function [cl,w] = clustercoeff(matrix)
% [cl,w] = clustercoeff(matrix)
% clustering coefficient
% cl: average over all nodes
% w: local values for each node
% Author: Marcus Kaiser  Date: 28.08.02

NODES=length(matrix);


    w=zeros(NODES,1);
    for i=1:NODES
     n = find(matrix(i,:)+matrix(:,i)');
%     [dummy,n1,dummy2]=find(matrix(i,:));
%     [n2,dummy,dummy2]=find(matrix(:,i));
%     n=union(n1,n2);
     n_e=0;
     l_n=length(n);
     for j=1:l_n
       [dummy,n_v,dummy2]=find(matrix(n(j),:));    
       n_e=n_e+l_n+length(n_v)-length(union(n,n_v));
     end;  
     if l_n>1
       w(i)=n_e/(l_n*(l_n-1));
     end;
    end;
    cl=mean(w);


return
