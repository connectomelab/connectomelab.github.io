% Plots the polynomial based time window functions
% used in all simulations.
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-09-15


CLASSES = 5;
integral = 0.2;
timewindow = prepareParmVector(CLASSES, integral);

cmap = zeros(CLASSES+1,3);
%cmap(1,:) = [1 1 1];
for c=1:CLASSES
  cmap(c+1,:) = [0.8*c/CLASSES 0.8*c/CLASSES 0.8*c/CLASSES];
end;

probdensity = zeros(CLASSES,81);
for c=1:CLASSES
  for t=1:161
      %probdensity(c,t)=ptimecos((t-1)/80,normdist(c,1),timewindow(c,2))/80;
      probdensity(c,t)=(ptimepoly((t-1)/160,timewindow(c,1),timewindow(c,2))-0.01)/0.99;
  end;
  sum(probdensity(c,:));
end;

hold on;
for c=1:CLASSES
  plot(0:0.00625:1, probdensity(c,:), 'Color', cmap(c,:));
end;
title('k=5, alpha=0.2');
xlabel('t');
ylabel('P_t_i_m_e^(^i^)(t)');
hold off;