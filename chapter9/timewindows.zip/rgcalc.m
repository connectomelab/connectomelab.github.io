function [ASP, CC] = rgcalc(nodes, edges, runs)
% function [ASP, CC] = rgcalc(nodes, edges, runs)
% calculates the average ASP and the CC of a random graph
% generated with randomgraph_symm
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-17
    ASP_arr=zeros(runs,1);
    CC_arr=zeros(runs,1);
    for i = 1:runs
        matrix=randomgraph_symm(nodes,edges);
        ASP_arr(i)=asp(matrix);
        CC_arr(i)=clustercoeff(matrix);
    end
    ASP=mean(ASP_arr);
    CC=mean(CC_arr);
    %fprintf('ASP: %f +- %f; CC: %f +- %f',ASP, std(ASP_arr)/sqrt(runs), CC, std(CC_arr)/sqrt(runs));
end