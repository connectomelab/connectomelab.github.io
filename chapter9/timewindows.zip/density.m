function d = density(matrix)
% d = density(matrix)
% calculates the density of the matrix as
% d = E / (V (V-1))
% E: number of edges; V: number of vertices
% equals the edge probability for random graphs
% Author: Marcus Kaiser  Date: 28 Aug 2002 
% updated to deal with non-square matrices (25 Jan 2006)
 
E = nnz(matrix);
V = length(matrix);
V2 = length(matrix');

if V==V2
  d = E / (V * (V-1));
else
  d = E / (V * V2);
end;


return