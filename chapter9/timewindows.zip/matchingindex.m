function [mat] = matchingindex(matrix,k)
%matchingindex(matrix,k) - yields matching index when
% 0<asp(i,j)<=k
% Author: Marcus Kaiser    Date: 15.8.02


% get asp matrix

[dummy,matrix]=asp(matrix);

n=size(matrix,1);



% get matrix where m(i,j)=1 when 0<asp(i,j)<=k

for i=1:n
  for j=1:n
    if (matrix(i,j)>k)
        matrix(i,j)=0;
    elseif (matrix(i,j)>1)
            matrix(i,j)=1;
    end
  end
end


% calculate matching indices for the edges
% sum(A and B) / sum(A or B)    matching edges divided by all existing edges

matchmatrix=zeros(n,n);
matchINmatrix=zeros(n,n);
matchOUTmatrix=zeros(n,n);

for i=1:n
   for j=1:n
     if (matrix(i,j)>0)
       swapij=matrix(i,j);
       swapji=matrix(j,i);
       matrix(i,j)=0;
       matrix(j,i)=0;
       matchINmatrix(i,j)= sum(matrix(i,:) & matrix(j,:)) / sum(matrix(i,:) | matrix(j,:))   ;
       matchOUTmatrix(i,j)= sum(matrix(:,i) & matrix(:,j)) / sum(matrix(:,i) | matrix(:,j))   ;
       matchmatrix(i,j) = ( matchINmatrix(i,j) + matchOUTmatrix(i,j) ) / 2;
       matrix(i,j)=swapij;
       matrix(j,i)=swapji;       
     end;
   end
end


mat=matchmatrix;

return 