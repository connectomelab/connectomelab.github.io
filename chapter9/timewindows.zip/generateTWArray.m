function A = generateTWArray;
% pre-calculate the time window function

A = zeros(101,101,1001);
for mu = 0.01:0.01:0.99
    for Int = 0.01:0.01:0.99
        sig = sigma(mu,Int);
        for t=0:0.001:1
            A(int16(100*mu+1),int16(100*Int+1),int16(1000*t+1))=ptimepoly(t,mu,sig);
        end
    end
end

end