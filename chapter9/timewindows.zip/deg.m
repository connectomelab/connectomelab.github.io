function  dl = deg(matrix,k);
% dl = deg(matrix,k)
% degree of node k
% Author: Marcus Kaiser   Date: 10.11.2002


dl=sum(matrix(k,:) + matrix(:,k)');


return