function l = wiringlength(matrix,positions)
% l = wiringlength(matrix,positions)
% wiring length of network with spatial node positions
% works for two- or three-dimensional positions
% Author: Marcus Kaiser  Date: 8 May 2003


n=size(positions,1);

l=0;
for i=1:n
    for j=1:n 
        if matrix(i,j) ~= 0
            % add euklidian distance between i and j to wiring length
            l = l + sum(( positions(i,:) - positions(j,:) ).^2).^0.5;
        end;
    end;
end;


return