function plot_chresults(A,tit)
% function plot_chresults(A,tit)
% plot results for the connection hypothesis script
% Author:           Florian Nisbach
% Date of creation: 2006-09
% Last change:      2006-09-14



pos=[360 216 418 706];
rot=[0.2503   -0.9682    0.0000    0.3589;...
    0.1180    0.0305    0.9925   -0.5705;...
    0.9609    0.2485   -0.1219    8.1165;...
         0         0         0    1.0000];
pic = slice(A,[],[],[1:8]);
title(tit);
colorbar;

xlabel('Integral');
set(gca,'XLim',[1,11]);
set(gca,'XTick',[1:2:11]);
set(gca,'XTickLabel','0.1|0.2|0.3|0.4|0.5|0.6');

ylabel('Time windows');
set(gca,'YLim',[1,8]);
set(gca,'YTick',[1:8]);
set(gca,'YTickLabel','3|4|5|6|7|8|9|10');

zlabel('nodes');
set(gca,'ZLim',[1,8]);
set(gca,'ZTick',[1:8]);
set(gca,'ZTickLabel','1-50|51-100|101-150|151-200|201-250|251-300|301-350|351-400');




set(gcf,'Position',pos);
view(rot);
end