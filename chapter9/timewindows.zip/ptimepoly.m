function p = ptimepoly(x,mu,sigma)
% function p = ptimepoly(x,mu,sigma)
% This function calculates the polynomial based time
% window functions, depending on mu and sigma
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-15
    lambda = -log(2)/log(mu);
    p = 0.99 * ( 16 * x.^(2*lambda) * (x.^lambda - 1).^2 ).^(1/sigma) + 0.01;
    
return