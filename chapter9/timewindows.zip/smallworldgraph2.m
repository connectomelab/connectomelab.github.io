function sw = smallworldgraph2(n,e,p);
% sw = smallworldgraph2(n,e,p)
% yields matrix of a small-world graph
% with n nodes and e edges
% algorithm described in: Watts & Strogatz, 1998


% constants
K = ceil(e / n); % neighbors
OneSideK = K / 2;
prob = p; % was 0.25
             % 0.1 for mac73



% generate initial matrix (p=0)
sw=zeros(n,n);
for i = 1:n
    for j=1:OneSideK   % neighboring nodes after node i
        neighbor = i + j;
        if neighbor > n
            neighbor = neighbor - n;
        end;
        sw(i, neighbor) = 1;
        sw(neighbor, i) = 1;
    end;
    for j=1:OneSideK   % neighboring nodes before node i
        neighbor = i - j;
        if neighbor < 1
            neighbor = neighbor + n;
        end;
        sw(i, neighbor) = 1;
        sw(neighbor, i) = 1;
    end;
end;


% rewiring (p=prob)
for j=1:OneSideK
    for i=1:n
        neighbor = i - j;  % neighbor j before node i
        if neighbor < 1
            neighbor = neighbor + n;
        end;
        if (sw(i, neighbor)==1) & (rand < prob)
            dummy = randperm(n);
            while (sw(i,dummy(1)) ~= 0) | (dummy(1) == i)
               dummy = randperm(n);
            end;
            sw(i,neighbor) = 0;
            sw(i,dummy(1)) = 1;
        end;

        neighbor = i + j;  % neighbor j after node i
        if neighbor > n
            neighbor = neighbor - n;
        end;
        if (sw(i, neighbor)==1) & (rand < prob)
            dummy = randperm(n);
            while (sw(i,dummy(1)) ~= 0) | (dummy(1) == i)
               dummy = randperm(n);
            end;
            sw(i,neighbor) = 0;
            sw(i,dummy(1)) = 1;
        end;
    end; % for i
end; % for j



% delete all but e edges
edges = sum(sum(sw));
victims = edges - e;
while victims > 0
    dummy = randperm(n);
    i = dummy(1);
    dummy = randperm(n);
    j = dummy(1);
    while sw(i,j)==0
        dummy = randperm(n);
        i = dummy(1);
        dummy = randperm(n);
        j = dummy(1);
    end;
    sw(i,j) = 0;
    victims = victims - 1;
end;


%edges = sum(sum(sw))


% analysis
%cc = clustercoeff(sw)
%d = density(sw)
%l = asp(sw)



