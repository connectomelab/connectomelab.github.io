% Calculate SW-Factors of the dataset
% Author:           Florian Nisbach
% Date of creation: 2006-08-23
% Last change:      2006-08-23
for i=1:8
for j=1:8
for k=1:11
[ASPrand,CCrand]=rgcalc(NODESLIST(j),round(A_Edges(i,j,k)),20);
SW_ASP(i,j,k)=A_ASP(i,j,k)/ASPrand;
SW_CC(i,j,k)=A_CC(i,j,k)/CCrand;
end
fprintf('j=%i, i=%i\n',j,i);
end
end
SW=SW_ASP.*SW_CC;