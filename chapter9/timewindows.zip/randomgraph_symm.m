function G = randomgraph_symm(n,e)
% function G = randomgraph_symm(n,e)
% generates the adjacency matrix of a symmetric random
% graph with n nodes and e edges
% Author:           Florian Nisbach
% Date of creation: 2006-08
% Last change:      2006-08-17

G = zeros(n,n);

while e>0
    a=round(1+(n-1)*rand(1));
    b=round(1+(n-1)*rand(1));
    if (a~=b)&G(a,b)==0
        G(a,b)=1; G(b,a)=1;
        e=e-1;
    end
end
end
    