function [neigh,inneigh,outneigh] = neighbours(matrix, k);
% [neigh,inneigh,outneigh] = neighbours(matrix, k);
% yields an array with the neighbours of node k
% where neighbours are nodes with incoming or 
% outgoing connections from or to node k
% % NB: assumes non-negative connection weights! (changed)
% Author: Marcus Kaiser
% Date: 22 Sept 2004 (18 Apr 2004)

inneigh = find(matrix(:, k));
outneigh = find(matrix(k, :));
neigh = union(inneigh,outneigh);


return
