% Apply normal ageing model over NKI subjects
close all 
clear
clc

load('Data');
load('edgeModel');
% NKI data
ConMat=NKI.ConnectionMatricesCT;
name=sprintf('normalAgeing_matrices_stage%0.2u', 0);
save(name, 'ConMat');
nsubj=size(ConMat,3);
age=NKI.AgeCT;
gender=NKI.GenderCT; % 1 is male, 2 is female (see readme)
gender(gender==2)=-1; % now 1 is male and -1 female

% Set simulation parameters
h=0.1; % time step
t=h:h:15; % simulating ~15 years
t([10,20,30,40,50,60,70,80,90,100,110,120,130,140,150])=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15];

% To track degradation
STRENGTH_CT=zeros(82,nsubj,length(t)+1);
for isubj=1:nsubj
    STRENGTH_CT(:,isubj,1)=sum(ConMat(:,:,isubj))';
end
% Apply normal ageing model
for ith=1:length(t) % for each temporal point
    output=sprintf('Time step (%u/%u)',ith, length(t));
    disp(output);
    % ---
    for isubj=1:nsubj % for each subject
        
        [agedmatrix, newage] = AgeingModel(ConMat(:,:,isubj), edgeModel, age(isubj), gender(isubj), h);
        ConMat(:,:,isubj)=agedmatrix;
        age(isubj)=newage;
        STRENGTH_CT(:,isubj,ith+1)=sum(agedmatrix)';
        
    end
    
    if ismember(t(ith), 1:15)
        name=sprintf('normalAgeing_matrices_stage%0.2u', t(ith));
        save(name, 'ConMat');
    end
    
end

save('STRENGTH_CT', 'STRENGTH_CT');





        

