function [NKICT_strength, NKIAD_strength, ADNICT_strength, ADNIAD_strength]=strength2optimization(NKI_CT, NKI_AD, ADNI_CT, ADNI_AD)

addpath(genpath('../../BCT')); % Brain Connectivity Toolbox

%% NKI dataset
nreg=size(NKI_CT,1);
nsubj=size(NKI_CT,3);
NKICT_strength=zeros(nsubj,nreg);
NKIAD_strength=zeros(nsubj, nreg);

for i=1:nsubj
    
    % normal ageing
    CIJ=NKI_CT(:,:,i);
    CIJ = weight_conversion(CIJ, 'autofix');
    NKICT_strength(i,:) = strengths_und(CIJ);
   
    % AD ageing
    CIJ=NKI_AD(:,:,i);
    CIJ = weight_conversion(CIJ, 'autofix');
    NKIAD_strength(i,:) = strengths_und(CIJ);

end


%% ADNI dataset
nreg=size(ADNI_CT,1);
nsubj=size(ADNI_CT,3);
ADNICT_strength=zeros(nsubj,nreg);
ADNIAD_strength=zeros(nsubj, nreg);

for i=1:nsubj
    
    % normal ageing
    CIJ=ADNI_CT(:,:,i);
    CIJ = weight_conversion(CIJ, 'autofix');
    ADNICT_strength(i,:) = strengths_und(CIJ);
   
    % AD ageing
    CIJ=ADNI_AD(:,:,i);
    CIJ = weight_conversion(CIJ, 'autofix');
    ADNIAD_strength(i,:) = strengths_und(CIJ);

end

