function [agedmatrix, newage] = AgeingModel(Matrix,edgeModel, age, gender, h)
%
% THIS IS A MODEL OF THE NORMAL AGEING PROCCESS BASED UPON FINDINGS FROM
% THE NKI DATASET. IT IS A SIMPLE FUNCTION THAT RANDOMLY SELECTS
% STREAMLINES THAT ARE TO BE DEGRADED BASED UPON THEIR LENGTH AND
% THICKNESS. 
%
% NOTE: THIS MODEL ONLY WORKS FOR MATRICES CREATED USING 82 REGIONS OF
% INTEREST
%
% Inputs:
% Matrix = This is the connection matrix (82x82) that the aging model will be
% applied to.
%
% distMatrix = This is a matrix (82x82) of the distances between any two connected
% regions.
%
% Outputs:
% agedmatrix = This is the new matrix (82x82) with the ageing model applied over 1
% year. 
%
% Created by Oliver Kennion 2016
% Modified by Antonio D�az-Parra 2017

ModelSize=edgeModel.ModelSize;
ModelParameters=edgeModel.ModelParameters;
mask=logical(tril(ones(82,82),-1));
% initialize variable
ageing = zeros(82,82);
indx=find(ModelSize>1 & mask);

for i=1:length(indx)
    [I,J] = ind2sub([82,82],indx(i));
    ageing(indx(i)) = ModelParameters(I,J,2) + ModelParameters(I,J,4)*gender + 2*ModelParameters(I,J,5)*age;
end

% Make the changes symmetrical across the diagonal
ageing = ageing + ageing';

% Creating the new aged matrix
agedmatrix = Matrix + h*ageing;
agedmatrix(agedmatrix<0)=0;
newage=age + h;
end
