close all
clear
clc

load NKIdata
ROInames=longnames;
thmin=45; % min age to be included in the construction of normal ageing model (45 by default)
thmax=81; % max age to be included in the construction of normal ageing model (81 by default)
indxage=find(control_age>=thmin & control_age<=thmax);
nsubj=length(indxage);
age=control_age(indxage);
gender=class_gender(indxage); % 1 is male, 2 is female (see readme)
indxmale=find(gender==1);
indxfemale=find(gender==2);
gender(gender==2)=-1; % now 1 is male and -1 female
% connectivity
control_connectivity=control_connectivity(indxage,:);
mask=logical(tril(ones(82,82),-1));
ConnectionMatrices=zeros(82,82,nsubj);
for i=1:nsubj
    weights=control_connectivity(i,:);
    net=ConnectionMatrices(:,:,i);
    net(mask)=weights;
    ConnectionMatrices(:,:,i)=net+net';
end
% common edges
groupNet=all(ConnectionMatrices,3);
groupNet=groupNet & mask;
edge_indx=find(groupNet);
% --------------------------------------------------
% Four different features are gonna be used to construct a model for each
% link, namely, age (feature 1), gender (feature 2), age*gender (feature 3), age^2 (feauture 4). Specifically, model
% selection (size 0, size 1, size 2, size 3 or size 4) based on the algorithm 
% "best subset selection" (see An Introduction to Statistical Learning) is performed individually for each link. To this end, we are gonna track
% the size, the features and the parameters in each link model. 
ModelSize=zeros(82,82,1); % number of parameters
ModelParameters=zeros(82,82,5); % the third dimension encodes the parameters of the model
% --------------------------------------------------
X=[age, gender]; % design matrix
for i=1:length(edge_indx)
    disp(sprintf('%u/%u',i,length(edge_indx)));
    % get data from this edge
    y=zeros(nsubj,1);
    for j=1:nsubj
        netj=ConnectionMatrices(:,:,j);
        y(j)=netj(edge_indx(i));
    end 
    
    % ******************************
    % ******************************
    % Best size 0 model
    % ******************************
    % ******************************
    % Model 1
    mod0=fitlm(X,y,'y ~ 1', 'Categorical', 2);
%     mod0
    best0=mod0;
    feat0=[true, false, false, false, false];
    % ******************************
    % ******************************
    % Best size 1 model
    % ******************************
    % ******************************
    % Model 2 (Age)
    mod1_1=fitlm(X,y,'y ~ x1', 'Categorical', 2);
%     mod1_1
    rmax=mod1_1.Rsquared.Ordinary;
    best1=mod1_1;
    feat1=[true, true, false, false, false];
    % Model 3 (Gender)
    mod1_2=fitlm(X,y,'y ~ x2', 'Categorical', 2);
%     mod1_2
    if mod1_2.Rsquared.Ordinary > rmax
        rmax=mod1_2.Rsquared.Ordinary;
        best1=mod1_2;
        feat1=[true, false, true, false, false];
    end
    % Model 4 (Age*Gender)
    mod1_3=fitlm(X,y,'y ~ x1:x2 ', 'Categorical', 2);
%     mod1_3
    if mod1_3.Rsquared.Ordinary > rmax
        rmax=mod1_3.Rsquared.Ordinary;
        best1=mod1_3;
        feat1=[true, false, false, true, false];
    end 
    % Model 5 (Age^2)
    mod1_4=fitlm(X,y,'y ~ x1^2 - x1', 'Categorical', 2);
%     mod1_4
    if mod1_4.Rsquared.Ordinary > rmax
        rmax=mod1_4.Rsquared.Ordinary;
        best1=mod1_4;
        feat1=[true, false, false, false, true];
    end
    % ******************************
    % ******************************
    % Best size 2 model
    % ******************************
    % ******************************
    % Model 6 (Age, Gender)
    mod2_1=fitlm(X,y,'y ~ x1 + x2', 'Categorical', 2);
%     mod2_1
    rmax=mod2_1.Rsquared.Ordinary;
    best2=mod2_1;
    feat2=[true, true, true, false, false];
    % Model 7 (Age, Age*Gender)
    mod2_2=fitlm(X,y,'y ~ x1 + x1:x2', 'Categorical', 2);
%     mod2_2
    if mod2_2.Rsquared.Ordinary > rmax
        rmax=mod2_2.Rsquared.Ordinary;
        best2=mod2_2;
        feat2=[true, true, false, true, false];
    end
    % Model 8 (Age, Age^2)
    mod2_3=fitlm(X,y,'y ~ x1^2', 'Categorical', 2);
%     mod2_3
    if mod2_3.Rsquared.Ordinary > rmax
        rmax=mod2_3.Rsquared.Ordinary;
        best2=mod2_3;
        feat2=[true, true, false, false, true];
    end
    % Model 9 (Gender, Age*Gender)
    mod2_4=fitlm(X,y,'y ~ x2 + x1:x2', 'Categorical', 2);
%     mod2_4
    if mod2_4.Rsquared.Ordinary > rmax
        rmax=mod2_4.Rsquared.Ordinary;
        best2=mod2_4;
        feat2=[true, false, true, true, false];
    end
    % Model 10 (Gender, Age^2)
    mod2_5=fitlm(X,y,'y ~ x2 + x1^2 - x1', 'Categorical', 2);
%     mod2_5
    if mod2_5.Rsquared.Ordinary > rmax
        rmax=mod2_5.Rsquared.Ordinary;
        best2=mod2_5;
        feat2=[true, false, true, false, true];
    end
    % Model 11 (Age*Gender, Age^2)
    mod2_6=fitlm(X,y,'y ~ x1:x2 + x1^2 - x1', 'Categorical', 2);
%     mod2_6
    if mod2_6.Rsquared.Ordinary > rmax
        rmax=mod2_6.Rsquared.Ordinary;
        best2=mod2_6;
        feat2=[true, false, false, true, true];
    end
    
    % ******************************
    % ******************************
    % Best size 3 model
    % ******************************
    % ******************************
    % Model 12 (Age, Gender, Age*Gender)
    mod3_1=fitlm(X,y,'y ~ x1 + x2 + x1:x2', 'Categorical', 2);
%     mod3_1
    rmax=mod3_1.Rsquared.Ordinary;
    best3=mod3_1;
    feat3=[true, true, true, true, false];
    % Model 13 (Age, Gender, Age^2)
    mod3_2=fitlm(X,y,'y ~ x1 + x2 + x1^2', 'Categorical', 2);
%     mod3_2
    if mod3_2.Rsquared.Ordinary > rmax
        rmax=mod3_2.Rsquared.Ordinary;
        best3=mod3_2;
        feat3=[true, true, true, false, true];
    end
    % Model 14 (Gender, Age*Gender, Age^2)
    mod3_3=fitlm(X,y,'y ~ x2 + x1:x2 + x1^2 - x1', 'Categorical', 2);
%     mod3_3
    if mod3_3.Rsquared.Ordinary > rmax
        rmax=mod3_3.Rsquared.Ordinary;
        best3=mod3_3;
        feat3=[true, false, true, true, true];
    end
    % Model 15 (Age, Age*Gender, Age^2)
    mod3_4=fitlm(X,y,'y ~ x1 + x1:x2 + x1^2', 'Categorical', 2);
%     mod3_4
    if mod3_4.Rsquared.Ordinary > rmax
        rmax=mod3_4.Rsquared.Ordinary;
        best3=mod3_4;
        feat3=[true, true, false, true, true];
    end
    
    % ******************************
    % ******************************
    % Best size 4 model
    % ******************************
    % ******************************
    % Model 16
    mod4=fitlm(X,y,'y ~ x1 + x2 + x1:x2 + x1^2', 'Categorical', 2);
%     mod4
    best4=mod4;
    feat4=[true, true, true, true, true];
    
    % ******************************
    % ******************************
    % Compare best0, best1, best2, best3 and best4 using AIC (take the model with minimum AIC)
    AICmin=best0.ModelCriterion.AIC;
    bestmodel=best0;
    feat=feat0;
    if best1.ModelCriterion.AIC < AICmin
        AICmin=best1.ModelCriterion.AIC;
        bestmodel=best1;
        feat=feat1;
    end
    if best2.ModelCriterion.AIC < AICmin
        AICmin=best2.ModelCriterion.AIC;
        bestmodel=best2;
        feat=feat2;
    end
    if best3.ModelCriterion.AIC < AICmin
        AICmin=best3.ModelCriterion.AIC;
        bestmodel=best3;
        feat=feat3;
    end
    if best4.ModelCriterion.AIC < AICmin
        AICmin=best4.ModelCriterion.AIC;
        bestmodel=best4;
        feat=feat4;
    end
    
    % store the best model for the current link 
    [I,J] = ind2sub([82,82],edge_indx(i));
    coeff=table2array(bestmodel.Coefficients);
    b=coeff(:,1);
    ModelSize(I,J)=length(find(feat));
    ModelParameters(I,J,feat)=b;
    
    % --- show data
    figure, scatter(age(indxmale), y(indxmale), 'b', 'LineWidth',1), xlabel('Age', 'FontSize', 14); ylabel('Streamline count', 'FontSize', 14), hold on
    scatter(age(indxfemale), y(indxfemale), 'r', 'LineWidth',1);    name=sprintf('%s-%s', ROInames{I},ROInames{J});
    legend({'Male', 'Female'}, 'Location', 'northeast');
    title(name);
    x=linspace(min(age), max(age), 500);
    malegender=ones(1, length(x));
    femalegender=-ones(1, length(x));
    plot(x, ModelParameters(I,J,1) + ModelParameters(I,J,2)*x + ModelParameters(I,J,3)*malegender + ModelParameters(I,J,4)*x.*malegender + ModelParameters(I,J,5)*x.^2, 'b', 'LineWidth', 2);
    if feat(3) || feat(4)
        plot(x, ModelParameters(I,J,1) + ModelParameters(I,J,2)*x + ModelParameters(I,J,3)*femalegender + ModelParameters(I,J,4)*x.*femalegender + ModelParameters(I,J,5)*x.^2, 'r', 'LineWidth', 2);
    else
    plot(x, ModelParameters(I,J,1) + ModelParameters(I,J,2)*x + ModelParameters(I,J,3)*femalegender + ModelParameters(I,J,4)*x.*femalegender + ModelParameters(I,J,5)*x.^2, 'k', 'LineWidth', 2);

    end
    set(gca, 'FontSize', 14)
    save_figure(sprintf('Edge_%0.2u',i));
    close;
      
end

ModelSize=ModelSize+ModelSize';

figure, imagesc(ModelSize); colorbar('FontSize', 14); title('Male', 'FontSize', 14); title('Model size');
save_figure('Model_size');
edgeModel.ModelSize=ModelSize;
edgeModel.ModelParameters=ModelParameters;
save('edgeModel', 'edgeModel');

clear
clc