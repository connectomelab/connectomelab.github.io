function [agedmatrix,newage,newxvec] = AlzModel(Matrix,edgeModel,age,gender,xvec,h, p)

% THIS IS A MODEL OF ALZHEIMERS DISEASE WHICH TAKES INTO ACCOUNT THE SPREAD
% OF THE PATHOLOGICAL MOLECULES TAU AND BETA AMYLOID. IT AIMS TO REPLICATE
% THEIR SPREAD ACCROSS THE BRAIN AND THE SUBSEQUENT AFFECT UPON THE
% CONNECTIONS WITHIN THE BRAIN. IT ALSO APPLIES THE NORMAL MODEL OF AGEING
% TO RECREATE THE DEGENERATION THAT OCCURS WITH NORMAL AGEING.
% 
% NOTE: THIS MODEL ONLY WORKS FOR MATRICES CREATED USING 82 REGIONS OF
% INTEREST
%
% Inputs:
% Matrix = This is the connection matrix (82x82) that the Alzheimer's model will be
% applied to.
%
% distMatrix = This is a matrix (82x82) of the distances between any two connected
% regions.
% 
% xvec = This is a column vector (82x1) of the concentration of tau within each
% node.
%
% yvec = This is a column vector (82x1) of the concentration of amyloid beta
% within each node.
%
% Outputs: 
% agedmatrix = This is the connection matrix (82x82) that the Alzheimer's model has
% been applied to.
%
% newxvec = This is a column vector (82x1) with the new concentrations of tau
% within each node after the disease process has been applied.
%
% newyvec = This is a column vector (82x1) with the new concentrations of amyloid
% beta within each node after the disease process has been applied.
%
% Created by Oliver Kennion 2016
% Modified by Antonio D�az-Parra 2017


%% NORMAL AGEING MODEL
ModelSize=edgeModel.ModelSize;
ModelParameters=edgeModel.ModelParameters;
mask=logical(tril(ones(82,82),-1));
% initialize variable
ageing = zeros(82,82);
indx=find(ModelSize>1 & mask);

for i=1:length(indx)
    [I,J] = ind2sub([82,82],indx(i));
    ageing(indx(i)) = ModelParameters(I,J,2) + ModelParameters(I,J,4)*gender + 2*ModelParameters(I,J,5)*age;
end

% Make the changes symmetrical across the diagonal
ageing = ageing + ageing';

%% AD AGEING MODEL
% *****************************
% *****************************
% 1 - How are misfolded proteins propagated across regions?
% *****************************
% *****************************
% Parameters
alpha = p(1); % diffusion constant
beta = p(2);
% ---
strength=sum(Matrix);
% Calculating the new concentration vector
dxdt = zeros(82,1);
for i = 1:82
    fx=0;
    for j = 1:82
        if Matrix(i,j)~=0
            fx=fx+alpha*Matrix(i,j)/strength(j)*xvec(j); % option 1
        end
    end
    dxdt(i)=(1-xvec(i))*fx;
end

% *****************************
% *****************************
% 2 - How does misfolded proteins affect weights?
% *****************************
% *****************************

% Calculating the change in weights due to misfolded proteins (tau in this case)
MPchange = zeros(82,82);

for i = 1:82
    for j = i:82
        MPchange(i,j) = -beta*Matrix(i,j)*(xvec(i)+xvec(j)); % option 1
    end
end
MPchange=MPchange+MPchange';
%% OUTPUTS
% Returning the outputs
agedmatrix = Matrix + h*MPchange + h*ageing;
agedmatrix(agedmatrix<0)=0;
newage=age + h;
newxvec = xvec + h*dxdt;

end
