function f=compute_cost_function(alpha, beta, reg)

load('Data');
load('edgeModel');
% NKI data
ConMat=NKI.ConnectionMatricesAD;
nsubj=size(ConMat,3);
age=NKI.AgeAD;
gender=NKI.GenderAD; % 1 is male, 2 is female (see readme)
gender(gender==2)=-1; % now 1 is male and -1 female
% Seed regions
MP=zeros(82,1);
% seed region
MP(reg)=1; % tau protein
MP(reg+82/2)=1;
% ---

% Set simulation parameters
h=0.1; % time step
t=h:h:15; % simulating ~15 years

% Apply AD ageing model
MPData=zeros(size(MP,1), length(t)+1, nsubj);
MPData(:,1,:)=repmat(MP, 1, 1, nsubj);
for ith=1:length(t) % for each temporal point
    output=sprintf('Time step (%u/%u) - Reg %u',ith, length(t), reg);
    disp(output);
    % ---
    for isubj=1:nsubj % for each subject

        [agedmatrix,newage,newxvec] = AlzModel(ConMat(:,:,isubj), edgeModel, age(isubj), gender(isubj), MPData(:,ith,isubj), h, [alpha, beta]);
        ConMat(:,:,isubj)=agedmatrix;
        age(isubj)=newage;
        MPData(:,ith+1,isubj)=newxvec;
        
    end
end

% ********************************************
% ********************************************
% compute cost function
% ********************************************
% ********************************************
% NKI AD
NKI_AD=ConMat;
% NKI CT
load('normalAgeing_matrices_stage15.mat')
NKI_CT=ConMat;
% ADNI CT
ADNI_CT=ADNI.matricesCT;
% ADNI AD
ADNI_AD=ADNI.matricesAD;

% ---
[NKICT_strength, NKIAD_strength, ADNICT_strength, ADNIAD_strength]=strength2optimization(NKI_CT, NKI_AD, ADNI_CT, ADNI_AD);
% diff
NKI_strength=mean(NKICT_strength)-mean(NKIAD_strength);
ADNI_strength=mean(ADNICT_strength)-mean(ADNIAD_strength);
% ---
f=pdist2(NKI_strength, ADNI_strength);


