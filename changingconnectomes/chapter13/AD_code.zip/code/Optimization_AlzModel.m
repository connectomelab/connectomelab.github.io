close all
clear
clc

% parameter space
alpha=0:0.05:1.5;
beta=0:0.005:0.15;

% seed regions
seeds=1:41; 

% initialize cost function
F=zeros(length(alpha), length(beta), length(seeds));

for iseed=1:length(seeds)
    
    for i=1:length(alpha)
        for j=1:length(beta)
            F(i,j,iseed)=compute_cost_function(alpha(i), beta(j), seeds(iseed));
        end
    end
   
end

save('seeds_costFunction',  'F', 'alpha', 'beta', 'seeds');
